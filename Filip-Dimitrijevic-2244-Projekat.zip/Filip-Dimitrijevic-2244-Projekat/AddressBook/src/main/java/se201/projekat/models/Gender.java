package se201.projekat.models;

public enum Gender {
    MALE, FEMALE, OTHER
}
