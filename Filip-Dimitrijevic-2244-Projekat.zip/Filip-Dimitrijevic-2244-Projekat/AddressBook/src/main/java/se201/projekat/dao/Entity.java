package se201.projekat.dao;

/**
 * Osnovni interfejs za sve sto se cuva u bazi
 */
public interface Entity {

    int getId();
    void setId(int id);
}
